#!/usr/bin/env python3.7
__all__=["random_words"]

from .generator import *