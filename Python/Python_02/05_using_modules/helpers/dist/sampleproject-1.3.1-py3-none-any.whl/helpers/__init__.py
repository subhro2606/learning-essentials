#!/usr/bin/env python3.8
__all__=['extract_upper']
from .string import *