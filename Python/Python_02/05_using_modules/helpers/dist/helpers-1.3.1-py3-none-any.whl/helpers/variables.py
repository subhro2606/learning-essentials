#!/usr/bin/env python3.8

print("Importing 'module' in 'extras'")
import module

name = "Subhrajit Sadhukhan"
print(f"__name__ in extras.py {__name__}")
